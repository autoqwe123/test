from queue import Queue
import time
from .utils import format_map
import threading

# PROTECT LESTING VER 1 BY H4CK

PROTECT_ATTR = {
    "protectkick": "ลบสมาชิก",
    "protectinvite": "เชิญสมาชิก",
    "protectqrcode": "ลิงค์ของกลุ่ม",
}

class Node:
    class Operation:
        TYPE = -99
        ADD_CONTACT_BY_MID = 0
        REQUEST_SQUAD = 1

    def __init__(self, lesting, client):
        self.lesting = lesting
        self.client = client
        self.lesting.local[self.client.profile.mid] = self.client
        self.operations = Queue()
        self.running = False
        self.lesting.user(client.profile.mid).squad = True

    def fetch(self):
        while True:
            self.startup = round(time.time() * 1000)
            self.running = False

            while True:
                ops = self.client.fetchOps()
                for op in ops:
                    if not self.running:
                        if op.createdTime < self.startup:
                            continue
                        self.running = True
                    self.operations.put(op)

    def executor(self):
        while True:
            try:
                threading.Thread(target=self.execute, args=(self.operations.get(),)).start()
            except:
                import traceback
                traceback.print_exc()

    def execute(self, op):

        if op.type == Node.Operation.TYPE:
            if op.action == Node.Operation.ADD_CONTACT_BY_MID:
                if op.mid not in self.client.contacts:
                    self.client.findAndAddContactsByMid(op.mid)
                    self.client.contacts.append(op.mid)
                    
            if op.action == Node.Operation.REQUEST_SQUAD:
                self.lesting.squad.apply(op.ticket, self.client.profile.mid)

        if op.type in [11, 122]:
            chat = self.lesting.chat(op.param1)
            param2 = self.lesting.user(op.param2)
            if self.client.profile.mid not in chat.squad:
                return
            if op.param1 in self.lesting.data.type["protect"]["qrcode"] and self.lesting.data.type["protect"]["qrcode"][op.param1]["status"]:
                if not (param2.squad or param2.owner):
                    if op.param1 in self.lesting.data.type["rank"]["admin"] and param2.key not in self.lesting.data.type["rank"]["admin"][op.param1]:
                        param2.blacklist = True
                        if self.lesting.messenger(op):
                            threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {param2.key})).start()
                            group = self.client.getChat(op.param1)
                            if group.extra.groupExtra.preventedJoinByTicket == False:
                                group.extra.groupExtra.preventedJoinByTicket = True
                                threading.Thread(target=self.client.updateChat, args=(group, 4,)).start()

        if op.type in [19, 133]:
            chat  = self.lesting.chat(op.param1)
            param2 = self.lesting.user(op.param2)
            param3 = self.lesting.user(op.param3)

            if self.client.profile.mid not in chat.squad:
                return

            if op.param1 in self.lesting.data.type["protect"]["kick"] and self.lesting.data.type["protect"]["kick"][op.param1]["status"]:
                if not (param2.squad or param2.owner):
                    if op.param1 in self.lesting.data.type["rank"]["admin"] and param2.key not in self.lesting.data.type["rank"]["admin"][op.param1]:
                        param2.blacklist = True
                        if self.lesting.messenger(op, "a"):
                            threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {param2.key})).start()

            if param2.squad or param2.owner:
                return

            if param3.key in chat.squad:
                if op.param1 in self.lesting.data.type["rank"]["admin"] and param2.key in self.lesting.data.type["rank"]["admin"][op.param1]:
                    return
                param2.blacklist = True

                if param3.key == self.client.profile.mid:
                    return

                if self.lesting.messenger(op, "a"):
                    threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {param2.key})).start()
                    group = self.client.chats[op.param1]
                    squad = {mid for mid in chat.squad if mid not in group.members}
                    invites = {mid for mid in squad if mid not in group.invites}
                    if param3.key not in invites:
                        invites.add(param3.key)
                    threading.Thread(target=self.client.inviteIntoChat, args=(chat.key, invites)).start()

                elif self.lesting.messenger(op, "b"):
                    for mid in self.client.chats[op.param1].members:
                        if mid == param2.key:
                            continue
                        if self.lesting.user(mid).blacklist:
                            threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {mid})).start()
        
            elif param3.owner:
                param2.blacklist = True
                if self.lesting.messenger(op, "a"):
                    threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {param2.key})).start()
                    if param3.key not in self.client.contacts:
                        self.client.findAndAddContactsByMid(param3.key)
                    threading.Thread(target=self.client.inviteIntoChat, args=(op.param1, {param3.key})).start()

            elif op.param1 in self.lesting.data.type["rank"]["admin"] and param3.key in self.lesting.data.type["rank"]["admin"][op.param1]:
                if op.param1 in self.lesting.data.type["rank"]["admin"] and param2.key in self.lesting.data.type["rank"]["admin"][op.param1]:
                    return
                param2.blacklist = True
                if self.lesting.messenger(op, "a"):
                    threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {param2.key})).start()
                    if param3.key not in self.client.contacts:
                        self.client.findAndAddContactsByMid(param3.key)
                    threading.Thread(target=self.client.inviteIntoChat, args=(op.param1, {param3.key})).start()

        if op.type in [13, 124]:
            chat   = self.lesting.chat(op.param1)
            param2 = self.lesting.user(op.param2)

            if self.client.profile.mid in op.param3:
                if param2.squad or param2.owner or self.client.profile.mid in chat.squad:
                    threading.Thread(target=self.client.acceptChatInvitation, args=(op.param1,)).start()
                else:
                    return

            if self.client.profile.mid not in chat.squad:
                return

            param3 = [self.lesting.user(mid) for mid in op.param3.split("\x1e")]
            if op.param1 in self.lesting.data.type["protect"]["invite"] and self.lesting.data.type["protect"]["invite"][op.param1]["status"]:
                if not (param2.squad or param2.owner):
                    if op.param1 in self.lesting.data.type["rank"]["admin"] and param2.key not in self.lesting.data.type["rank"]["admin"][op.param1]:
                        param2.blacklist = True
                        if self.lesting.messenger(op, "a"):
                            threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {param2.key})).start()
                            for user in param3:
                                if not (user.squad or user.owner):
                                    if op.param1 in self.lesting.data.type["rank"]["admin"] and user.key not in self.lesting.data.type["rank"]["admin"][op.param1]:
                                        user.blacklist = True
                                        threading.Thread(target=self.client.cancelChatInvitation, args=(op.param1, {user.key})).start()

            if param2.squad or param2.owner:
                return

            if param2.blacklist or any(filter(lambda user: user.blacklist == True, param3)):
                param2.blacklist = True
                for user in param3:
                    user.blacklist = True

                if self.lesting.messenger(op, "a"):
                    threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {param2.key})).start()
                    for user in param3:
                        threading.Thread(target=self.client.cancelChatInvitation, args=(op.param1, {user.key})).start()

        if op.type in [17, 130]:
            param2 = self.lesting.user(op.param2)
            if param2.squad:
                return
            if param2.blacklist:
                if self.lesting.messenger(op):
                    threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {param2.key})).start()
            
        if op.type in [32, 126]:
            chat  = self.lesting.chat(op.param1)
            param2 = self.lesting.user(op.param2)
            if self.client.profile.mid not in chat.squad:
                return
            param3 = self.lesting.user(op.param3)
            if param3.key in chat.squad:
                if op.param1 in self.lesting.data.type["rank"]["admin"] and param2.key in self.lesting.data.type["rank"]["admin"][op.param1]:
                    return
                param2.blacklist = True
                if param3.key == self.client.profile.mid:
                    return
                if self.lesting.messenger(op, "a"):
                    threading.Thread(target=self.client.deleteOtherFromChat, args=(chat.key, {param2.key}, )).start()
                    threading.Thread(target=self.client.inviteIntoChat, args=(chat.key, {param3.key}, )).start()

            elif param3.owner:
                param2.blacklist = True
                if self.lesting.messenger(op, "a"):
                    threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {param2.key})).start()
                    if param3.key not in self.client.contacts:
                        self.client.findAndAddContactsByMid(param3.key)
                    threading.Thread(target=self.client.inviteIntoChat, args=(op.param1, {param3.key})).start()

            elif op.param1 in self.lesting.data.type["rank"]["admin"] and param3.key in self.lesting.data.type["rank"]["admin"][op.param1]:
                if op.param1 in self.lesting.data.type["rank"]["admin"] and param2.key in self.lesting.data.type["rank"]["admin"][op.param1]:
                    return
                param2.blacklist = True
                if self.lesting.messenger(op, "a"):
                    threading.Thread(target=self.client.deleteOtherFromChat, args=(op.param1, {param2.key})).start()
                    if param3.key not in self.client.contacts:
                        self.client.findAndAddContactsByMid(param3.key)
                    threading.Thread(target=self.client.inviteIntoChat, args=(op.param1, {param3.key})).start()


        if op.type in [26]:
            msg = op.message
            to  = msg.to
            chat = self.lesting.chat(msg.to)
            user = self.lesting.user(msg._from)

            if msg.contentType == 0:
                text = msg.text
                if text is None: # E2EE was enable
                    return
                
                command, args = self.lesting.command(text)
                
                if user.owner:
                    if command == "help":
                        if self.lesting.messenger(op):
                            text = "\n".join([
                                "-command help:",
                                "🔰 sp",
                                "🔰 change (name)",
                                "🔰 protect [type]",
                                "🔰 in [count]",
                                "🔰 reinvite",
                                "🔰 kick (@)",
                                "🔰 status",
                                "🔰 leave",
                                "\n"
                                "-admin help:",
                                "🎭 admin",
                                "🎭 clradmin",
                                "🎭 admin apply (@)",
                                "🎭 admin remove (@)",
                                "\n"
                                "-protect help:",
                                "🛡 protect",
                                "🛡 protectkick (on/off)",
                                "🛡 protectinvite (on/off)",
                                "🛡 protectqrcode (on/off)",
                            ])
                            self.client.sendMessage(to, text)
                            
                    if command == "sp":
                        if self.client.profile.mid not in chat.squad:
                            return
                        if "a" not in args or self.lesting.messenger(op):
                            c = 1
                            if "c" in args:
                                ci = args.index("c") + 1
                                if len(args) > ci:
                                    cs = args[ci]
                                    if cs.isdigit():
                                        c = int(cs)
    
                            def test():
                                s = time.time()
                                self.client.getProfile()
                                e = time.time() - s
                                self.client.sendMessage(to, "%s [%s ms]" % (str(e)[:7], int(e*1000)))
    
                            for _ in range(c):
                                test()
    
                    if command == "clear":
                        if self.lesting.messenger(op):
                            users = list(filter(lambda user: user.blacklist, [self.lesting.user(mid) for mid in self.lesting.user.values]))
                            for user in users:
                                user.blacklist = False
                            self.client.sendMessage(to, "clear %s blacklist(s)" % (len(users)))
    
                    if command == "status": 
                        if self.client.profile.mid not in chat.squad:
                            return
                        try:
                            self.client.inviteIntoChat(to, {self.client.profile.mid})
                            limit = False
                        except:
                            limit = True
                        self.client.sendMessage(to, "limit" if limit else "ready")
    
                    if command == "kick":
                        if self.client.profile.mid not in chat.squad:
                            return
                        if self.lesting.messenger(op):
                            MENTION = msg.contentMetadata.get("MENTION", None)
                            if MENTION:
                                chat = self.client.chats[to]
                                MENTIONEES = eval(MENTION)["MENTIONEES"]
                                for mention in MENTIONEES:
                                    if mention["M"] in chat.members:
                                        self.lesting.user(mention["M"]).blacklist = True
                                        self.client.deleteOtherFromChat(to, {mention["M"]})
    
                    if command == "reinvite": 
                        if self.lesting.messenger(op):
                            chat = self.lesting.chat(to)
                            if chat.squad == []:
                                self.client.sendMessage(to, "no squad on this group")
                                return
                            group = self.client.chats[to]
                            invites = {mid for mid in chat.squad if mid not in group.members and mid not in group.invites}
                            if invites:
                                self.client.inviteIntoChat(to, invites)
                            else:
                                self.client.sendMessage(to, "squad already on group")
    
                    if command == "in":
                        if self.lesting.messenger(op):
                            if len(args) >= 1:
                                if not args[0].isdigit():
                                    self.client.sendMessage(to, "in [count:int]")
                                    return
                                chat = self.lesting.chat(to)
                                count = int(args[0])
                                if count == 0:
                                    chat.squad = []
                                    self.client.sendMessage(to, "delete squad")
                                    return
                                accept = self.lesting.squad.request(count, self.client.profile.mid)
                                if not accept:
                                    self.client.sendMessage(to, "no accept squad")
                                    return
                                chat.squad = accept
                                group = self.client.chats[to]
                                invites = {mid for mid in chat.squad if mid not in group.members and mid not in group.invites}
                                self.client.sendMessage(to, "squad: %s" % (count))
                                if invites:
                                    self.client.inviteIntoChat(to, invites)
                            else:
                                self.client.sendMessage(to, "in [count:int]")

                    if command == "clradmin":
                        if self.client.profile.mid not in chat.squad:
                            return
                        if self.lesting.messenger(op):
                            if to not in self.lesting.data.type["rank"]["admin"]:
                                self.lesting.data.type["rank"]["admin"][to] = []
                            if self.lesting.data.type["rank"]["admin"][to] == []:
                                self.client.sendMessage(to, "ไม่มีแอดมินกลุ่ม\nอยู่ในระบบอยู่แล้ว")
                            else:
                                self.lesting.data.type["rank"]["admin"][to] = []
                                self.client.sendMessage(to, "ล้างแอดมินกลุ่ม\nเสร็จสิ้น")

                    if command == "admin":
                        if self.client.profile.mid not in chat.squad:
                            return
                        if self.lesting.messenger(op):
                            if to not in self.lesting.data.type["rank"]["admin"]:
                                self.lesting.data.type["rank"]["admin"][to] = []
                            if len(args) >= 1:
                                toggle = args[0]
                                MENTION = msg.contentMetadata.get("MENTION", None)
                                if MENTION:
                                    chat = self.client.chats[to]
                                    MENTIONEES = eval(MENTION)["MENTIONEES"]
                                    for mention in MENTIONEES:
                                        if mention["M"] in chat.members:
                                            if toggle == "apply":
                                                if mention["M"] not in self.lesting.data.type["rank"]["admin"][to]:
                                                    self.lesting.data.type["rank"]["admin"][to].append(mention["M"])
                                                    self.client.sendMessage(to, "เพิ่มเสร็จสิ้น")
                                                else:
                                                    self.client.sendMessage(to, "อยู่ในระบบอยู่แล้ว")
                                            elif toggle == "remove":
                                                if mention["M"] in self.lesting.data.type["rank"]["admin"][to]:
                                                    self.lesting.data.type["rank"]["admin"][to].remove(mention["M"])
                                                    self.client.sendMessage(to, "ลบเสร็จสิ้น")
                                                else:
                                                    self.client.sendMessage(to, "ไม่ได้อยู่ในระบบอยู่แล้ว")                                                                                                      
                                else:
                                    self.client.sendMessage(to, "plz mention\nadmin apply or\nadmin remove")                                                                                                     
                            else:
                                if not self.lesting.data.type["rank"]["admin"][to]:
                                    self.client.sendMessage(to, "ไม่พบข้อมูล")
                                else:
                                    text = "รายชื่อแอดมินกลุ่ม:\n"
                                    text += "\n".join([f'- {self.client.getContact(mid).displayName}' for mid in self.lesting.data.type["rank"]["admin"][to]])
                                    self.client.sendMessage(to, text)

                    if command == "protect":
                        if self.client.profile.mid not in chat.squad:
                            return
                        if self.lesting.messenger(op):
                            text = "---[ ᴘʀᴏᴛᴇᴄᴛ ᴀʟʟ ]---\n"
                            text += "\nป้องกันเตะ : "
                            if to in self.lesting.data.type["protect"]["kick"] and self.lesting.data.type["protect"]["kick"][to]["status"]:
                                text += "􀔃􀅤on􏿿"
                            else:
                                text += "􀔃􀅠ผิด􏿿"
                            text += "\nป้องกันเชิญ : "
                            if to in self.lesting.data.type["protect"]["invite"] and self.lesting.data.type["protect"]["invite"][to]["status"]:
                                text += "􀔃􀅤on􏿿"
                            else:
                                text += "􀔃􀅠ผิด􏿿"
                            text += "\nป้องกันลิ้งค์ : "
                            if to in self.lesting.data.type["protect"]["qrcode"] and self.lesting.data.type["protect"]["qrcode"][to]["status"]:
                                text += "􀔃􀅤on􏿿"
                            else:
                                text += "􀔃􀅠ผิด􏿿"
                            self.client.sendMessage(to, text)

                    if command in PROTECT_ATTR:
                        if self.client.profile.mid not in chat.squad:
                            return
                        if self.lesting.messenger(op):
                            PROTECT = command.split("protect")[1]
                            if to not in self.lesting.data.type["protect"][PROTECT]:
                                self.lesting.data.type["protect"][PROTECT][to] = {"status": False}
                            if len(args) >= 1:
                                toggle = args[0]
                                if toggle == "on":
                                    if self.lesting.data.type["protect"][PROTECT][to]["status"]:
                                        self.client.sendMessage(to, "เปิดอยู่แล้ว")
                                    else:
                                        self.lesting.data.type["protect"][PROTECT][to]["status"] = True
                                        self.client.sendMessage(to, "เปิดเสร็จสิ้น")
                                elif toggle == "off":
                                    if not self.lesting.data.type["protect"][PROTECT][to]["status"]:
                                        self.client.sendMessage(to, "ปิดอยู่แล้ว")
                                    else:
                                        self.lesting.data.type["protect"][PROTECT][to]["status"] = False
                                        self.client.sendMessage(to, "ปิดเสร็จสิ้น")

                    if command == "exec":
                        if self.lesting.messenger(op):
                            try:
                                exec(" ".join(args).strip())
                            except:
                                import traceback
                                error = traceback.format_exc()
                                self.client.sendMessage(to, str(error).strip())
    
                    if command == "change":
                        name = " ".join(args)
                        name = name.replace("{index}", str(list(self.lesting.local).index(self.client.profile.mid) + 1))
                        self.client.profile.displayName = name
                        self.client.updateProfile(self.client.profile)
                        self.client.sendMessage(to, "successfully update display name")
    
                    if command == "leave":
                        self.client.deleteSelfFromChat(to)